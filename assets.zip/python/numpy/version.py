
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.19.0'
version = '1.19.0'
full_version = '1.19.0'
git_revision = '92ebe1e9a6aeb47a881a1226b08218175776f9ea'
release = True

if not release:
    version = full_version
